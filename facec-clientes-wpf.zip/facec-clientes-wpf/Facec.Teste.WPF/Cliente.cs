﻿using System.Text.Json.Serialization;

namespace Facec.Teste.WPF
{
    public class Cliente
    {

        [JsonPropertyName("documento")]
        public string Documento { get; set; }

        [JsonPropertyName("nome")]
        public string Nome { get; set; }


        public Cliente()
        {

        }
        [JsonConstructor]
        public Cliente(string documento, string nome)
        {
            Documento = documento;
            Nome = nome;
        }
    }
}